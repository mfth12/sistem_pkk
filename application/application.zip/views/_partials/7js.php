        <script src="<?php echo base_url('assets/jquery-3.5.1.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/bootstrap.bundle.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/Chart.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/jquery.dataTables.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/dataTables.bootstrap4.min.js') ?>"></script>
        <!--  -->
        <!--  -->
        <script src="<?php echo base_url('js/scripts.js') ?>"></script>
        <script src="<?php echo base_url('assets/demo/datatables-demo.js') ?>"></script>
